package com.stc.assessment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stc.assessment.model.PermissionGroup;
import com.stc.assessment.repository.PermissionGroupRepository;

@Service
public class PermissionGroupService {

	@Autowired
	private PermissionGroupRepository permissionGroupRepository;
	
	public void create(PermissionGroup permissionGroup) {
		PermissionGroup n = new PermissionGroup();
		n.setGroupName(permissionGroup.getGroupName());
		permissionGroupRepository.save(n);
	}

	public List<PermissionGroup> getAll() {
		return permissionGroupRepository.findAll();
		
	}
	
}
