package com.stc.assessment.model;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "ITEM")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Item {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
	
	@Column(name = "type")
    private String type;
	
	@Column(name = "name")
    private String name;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "permissionGroupId")
    private PermissionGroup permissionGroup;
	
}
