package com.stc.assessment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stc.assessment.model.Permission;
import com.stc.assessment.repository.PermissionRepository;

@Service
public class PermissionService {

	@Autowired
	private PermissionRepository permissionRepository;
	
	public void create(Permission permission) {
		permissionRepository.save(permission);
	}
}
