package com.stc.assessment.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Permission")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Permission {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
	
	@Column(name = "userEmail")
    private String userEmail;
	
	@Column(name = "permissionLevel")
    private String permissionLevel;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "groupId", referencedColumnName = "id")
    private PermissionGroup groupId;
}
