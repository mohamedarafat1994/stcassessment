package com.stc.assessment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.stc.assessment.model.File;
import com.stc.assessment.model.Item;
import com.stc.assessment.model.PermissionGroup;
import com.stc.assessment.service.FileService;
import com.stc.assessment.service.ItemService;
import com.stc.assessment.service.PermissionGroupService;

@RestController

public class FileSystemController {
	
	@Autowired
	private ItemService itemService;
	
	@Autowired
	private PermissionGroupService permissioGroupService;
	
	
	@PostMapping(value = "/items", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Object> createItem(@RequestBody Item item){
		itemService.create(item);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@PostMapping(consumes = "application/json", produces = "application/json", value="/permissiongroup")
    public ResponseEntity<Object> createPermissionGroup(@RequestBody PermissionGroup permissionGroup){
		permissioGroupService.create(permissionGroup);
        return new ResponseEntity<>(HttpStatus.OK);
    }
	
	@GetMapping(produces = "application/json", value="/permissiongroup")
    public ResponseEntity<List<PermissionGroup>> getAllPermissionGroups(){
        return new ResponseEntity<List<PermissionGroup>>(permissioGroupService.getAll(),HttpStatus.OK);
    }
}
