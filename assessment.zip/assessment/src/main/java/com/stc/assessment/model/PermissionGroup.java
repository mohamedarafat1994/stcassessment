package com.stc.assessment.model;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "PermissionGroup")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PermissionGroup {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
	
	@Column(name = "groupName")
    private String groupName;
	
}
