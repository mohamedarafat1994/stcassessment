package com.stc.assessment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stc.assessment.model.File;
import com.stc.assessment.repository.FileRepository;

@Service
public class FileService {

	@Autowired
	private FileRepository fileRepository;

	public Object getAllFiles() {
		// TODO Auto-generated method stub
		return null;
	}

	public void savePost(File file) {
		// TODO Auto-generated method stub
		
	}
	
}
