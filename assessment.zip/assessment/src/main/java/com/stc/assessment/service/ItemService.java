package com.stc.assessment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stc.assessment.model.Item;
import com.stc.assessment.repository.ItemRepository;

@Service
public class ItemService {

	@Autowired
	private ItemRepository itemRepository;

	public void create(Item item) {
		itemRepository.save(item);
	}
	
}
